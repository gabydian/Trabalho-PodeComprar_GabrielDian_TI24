const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.post('/idade-minima', (req, res) => {
  const { pais, anoNascimento } = req.body;
  const idade = new Date().getFullYear() - Number(anoNascimento);

  let podeComprar;

  switch (pais) {
    case 'BR':
      podeComprar = idade >= 18;
      break;
    case 'JP':
      podeComprar = idade >= 19;
      break;
    case 'EUA':
      podeComprar = idade >= 21;
      break;
    default:
      podeComprar = false;
      break;
  }

  res.json({ podeComprar });
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
